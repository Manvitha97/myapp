package com.cg.myapp.pl;

import com.cg.myapp.dto.Product;
import com.cg.myapp.exception.ProductException;
import com.cg.myapp.service.IProductService;
import com.cg.myapp.service.ProductService;

public class Client {

	public static void main(String[] args) {
		IProductService productService = new ProductService();
		
		Product newProduct = new Product();
		newProduct.setName("Water Bottle");
		newProduct.setPrice(45.0);
		
		try {
			productService.addProduct(newProduct);
		} catch (ProductException e) {
			System.out.println(e.getMessage());
		}
		

	}

}
