package com.cg.myapp.service;

import com.cg.myapp.dao.IProductDao;
import com.cg.myapp.dao.ProductDao;
import com.cg.myapp.dto.Product;
import com.cg.myapp.exception.ProductException;

public class ProductService implements IProductService {

	private IProductDao productDao;
	
	public ProductService() {
		productDao = new ProductDao();
	}
	
	/* (non-Javadoc)
	 * @see com.cg.myapp.service.IProductService#addProduct(com.cg.myapp.dto.Product)
	 */
	@Override
	public int addProduct(Product product) throws ProductException {
		int nextId = productDao.getNextProductId();
		product.setId(nextId);
		if(productDao.addProduct(product)) {
			return nextId;
		}
		return 0;
	}
	
	/* (non-Javadoc)
	 * @see com.cg.myapp.service.IProductService#getProduct(int)
	 */
	@Override
	public Product getProduct(int id) throws ProductException {
		return productDao.getProduct(id);
	}
	
	
}
