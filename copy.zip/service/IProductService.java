package com.cg.myapp.service;

import com.cg.myapp.dto.Product;
import com.cg.myapp.exception.ProductException;

public interface IProductService {

	public abstract int addProduct(Product product) throws ProductException;

	public abstract Product getProduct(int id) throws ProductException;

}