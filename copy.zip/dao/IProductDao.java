package com.cg.myapp.dao;

import com.cg.myapp.dto.Product;
import com.cg.myapp.exception.ProductException;

public interface IProductDao {

	public abstract boolean addProduct(Product product) throws ProductException;

	public abstract Product getProduct(int id) throws ProductException;

	public abstract int getNextProductId() throws ProductException;

}