package com.cg.myapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.myapp.exception.ProductException;

public class DBUtil {

	private DBUtil() {}
	
	private static Connection connection;
	
	public static Connection getConnection() throws ProductException {
		try {
			if(connection==null || connection.isClosed()) {
				String url = "jdbc:oracle:thin:@localhost:1521:XE";
				String username = "hr";
				String password = "hr";
				connection = DriverManager.getConnection(url, username, password);
			}
		} catch (SQLException e) {
			throw new ProductException(e.getMessage());
		}
		return connection;
	}
}
