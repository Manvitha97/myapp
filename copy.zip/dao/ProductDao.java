package com.cg.myapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.myapp.dto.Product;
import com.cg.myapp.exception.ProductException;

public class ProductDao implements IProductDao {

	//insertion java (product) -->(id, name,price) db 
	
	/* (non-Javadoc)
	 * @see com.cg.myapp.dao.IProductDao#addProduct(com.cg.myapp.dto.Product)
	 */
	@Override
	public boolean addProduct(Product product) throws ProductException {
		String sql = "INSERT INTO product_master VALUES(?,?,?)";
		boolean result = false;
		Connection connection = DBUtil.getConnection();
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setInt(1, product.getId());
			pst.setString(2, product.getName());
			pst.setDouble(3, product.getPrice());
			if(pst.executeUpdate()==1) {
				result = true;
			}
		} catch (SQLException e) {
			throw new ProductException(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ProductException(e.getMessage());
			}
		}
		return result;
	}
	
	//retrieval of product (id) --> (product)
	
	/* (non-Javadoc)
	 * @see com.cg.myapp.dao.IProductDao#getProduct(int)
	 */
	@Override
	public Product getProduct(int id) throws ProductException {
		String sql = "SELECT * FROM product_master WHERE id=?";
		Connection connection = DBUtil.getConnection();
		Product product =null;
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				product = new Product();
				product.setId(rs.getInt("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getDouble("price"));
			}
		} catch (SQLException e) {
			throw new ProductException(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ProductException(e.getMessage());
			}
		}
		return product;
	}
	
	/* (non-Javadoc)
	 * @see com.cg.myapp.dao.IProductDao#getNextProductId()
	 */
	@Override
	public int getNextProductId() throws ProductException {
		String sql = "SELECT prod_master_seq.NEXTVAL FROM dual";
		int result = 0;
		Connection connection =DBUtil.getConnection();
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new ProductException(e.getMessage());
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ProductException(e.getMessage());
			}
		}
		return result;
	}
}
